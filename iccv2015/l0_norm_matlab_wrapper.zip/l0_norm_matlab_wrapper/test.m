I = im2double(imread('input.jpg'));
tic;
[I, L] = l0_gradient_minimization(I, 0.5);
toc;
RGB = label2rgb(L, 'jet', [1 1 1], 'shuffle');
figure;imshow(RGB);