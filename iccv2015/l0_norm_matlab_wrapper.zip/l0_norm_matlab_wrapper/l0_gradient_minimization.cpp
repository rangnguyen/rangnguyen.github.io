/*==========================================================
 * arrayProduct.c - example in MATLAB External Interfaces
 *
 * Multiplies an input scalar (multiplier) 
 * times a 1xN matrix (inMatrix)
 * and outputs a 1xN matrix (outMatrix)
 *
 * The calling syntax is:
 *
 *		outMatrix = arrayProduct(multiplier, inMatrix)
 *
 * This is a MEX-file for MATLAB.
 * Copyright 2007-2012 The MathWorks, Inc.
 *
 *========================================================*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <string>
#include <fstream>
#include "mex.h"


void createNeighbour(int rows, int cols, int maxSize, int*& NB, int*& nNB)
{
	int inc = 0;

	for(int j = 0; j < cols; j++)
	{
		for(int i = 0; i < rows; i++)
		{			
			int curI = inc*maxSize-1;
			int count = 0;
			if(j+1 < cols)
			{
				NB[++curI] = i+(j+1)*rows;	
				NB[++curI] = 1;
				count += 2;
			}
			if(i+1 < rows)
			{
				NB[++curI] = i+1+j*rows;
				NB[++curI] = 1;
				count += 2;
			}
			if(j > 0)
			{
				NB[++curI] = i+(j-1)*rows;	
				NB[++curI] = 1;
				count += 2;
			}
			if(i > 0)
			{
				NB[++curI] = i-1+j*rows;	
				NB[++curI] = 1;
				count += 2;
			}
			nNB[inc] = count;
			inc++;
		}
	}
}

void l0_norm(double* inImage, double* outImage, double* G, int rows, int cols, int bands, double threshold)
{
    int maxSize = 32;
    int maxLoop = 100;
    
	int M = rows * cols;
	int numOfPixels = M;
	double total = 0;
	double step = (double)1/maxLoop;
	double ct = 0;
	double t = threshold;


	double* Y = new double[bands*M];
	double* sumY = new double[bands*M];
	for(int i = 0; i<bands*M; i++)
	{
		sumY[i] = Y[i] = inImage[i];
	}


	int* NB = new int[M*maxSize];
	int* nNB = new int[M];
	int* maxNB = new int[M];
	int* W = new int[M];
	int* IDX = new int[M];
	int* lutIDX = new int[M];
	int* hashID = new int[M];
	bool* pagefault = new bool[M];
	int** startpage = new int*[M];
	int*tempNB = new int[M];


	for(int i = 0; i < M; i++)
	{
		G[i] = i;
		IDX[i] = i;
		lutIDX[i] = i;
		W[i] = 1;
		maxNB[i] = maxSize;
		hashID[i] = -1;
		pagefault[i] = false;
		startpage[i] = &NB[i*maxSize];
	}

	int iter = 0;

	createNeighbour(rows, cols, maxSize, NB, nNB);
	double totalOfPixel = rows * cols;
	double curThresh = 0;
	// All other runs	
	while(iter <= maxLoop)
	{
		curThresh = ct*t;
		ct += step;

		
		for(int i = 0; i < M; i++)
		{
			int idx1 = IDX[i];				
			int* startI1 = startpage[idx1];
			int rIdx1 = idx1;

			int FIX_LOOP_TIMES = nNB[idx1];
			
			//			
			// create hashIDX			
			for(int hi = 0; hi < nNB[idx1]; hi = hi+2)
			{
				hashID[*(startI1+hi)] = hi;
				tempNB[hi] = *(startI1 + hi);
				tempNB[hi+1] = *(startI1 + hi + 1);
			}
			
			for(int j = 0; j < nNB[idx1]; j+=2)
			{		
				int len = *(startI1+j+1);
				int idx2 = *(startI1 + j);
				int* startI2 = startpage[idx2];
				int rIdx2 = idx2;
                
                double d = 0;
                for (int b=0; b<bands; b++)
                {
                    double db = Y[rIdx1+b*numOfPixels] - Y[rIdx2+b*numOfPixels];
                    d += db*db;
                }

				
				int sumW = W[idx1] + W[idx2];
				
				if(d*W[idx1]*W[idx2]/sumW/len <= curThresh) // Eq. 12 in the paper
				{	

					// Join and erase weigh set
					W[idx1] += W[idx2];			
					G[idx2] = G[idx1];

					
					for (int b = 0; b < bands; b++)
					{
						sumY[rIdx1 + b*numOfPixels] += sumY[rIdx2 + b*numOfPixels];
						Y[rIdx1 + b*numOfPixels] = sumY[rIdx1 + b*numOfPixels] / W[idx1];
					}

					////Update hashID
					hashID[idx2] = -1;			
					
					
					// Insert neighbour of idx2 into idx1					
					for(int t =0 ; t<nNB[idx2]; t = t+2)
					{
						int aa = *(startI2+t);
						int la = *(startI2+t+1);
						int* startIa = startpage[aa];
						if (aa == idx1)
							continue;

						// Check if aa is the common neighbor of idx1 and idx2
						int find = hashID[aa];						
						if (find > -1) // If YES
						{
							*(startI1+find+1) += la;							
							int k = 0;
							while(*(startIa+k) != idx1)
							{
								k += 2;
							}							
							// Update the new connection number
							*(startIa+k+1) = *(startI1+find+1);	

							// Erase idx2 from its neighbors
							k = 0;
							while(*(startIa+k) != idx2)
							{
								k += 2;
							}	

							nNB[aa] -= 2;
							for (int tk = k; tk < nNB[aa]; tk += 2)
							{
								*(startIa + tk) = *(startIa + tk + 2);
								*(startIa + tk + 1) = *(startIa + tk + 3);
							}							
	
						}
						else // If NO
						{							
							if(nNB[idx1] >= maxNB[idx1])
							{
								
								if(pagefault[idx1] || maxNB[idx1+maxNB[idx1]/maxSize] != 0)
								{
									// PAGE FAULT									
									int*temp = new int [2*maxNB[idx1]];
									maxNB[idx1] = 2*maxNB[idx1];
									// Copy to new page
									for(int ii = 0; ii < nNB[idx1]; ii++)
									{
										temp[ii] = *(startI1+ii);
									}
									if(pagefault[idx1])
									{
										delete[] startpage[idx1];
									}
									startpage[idx1] = &temp[0];
									startI1 = startpage[idx1];
									pagefault[idx1] = true;	
									//cout<<"Page fault!\n";
								}
								else
								{
									maxNB[idx1] += maxSize;
								}

							}							
							
							*(startI1+nNB[idx1])   = aa;
							*(startI1+nNB[idx1]+1) = la;
							//Update hashID
							hashID[aa] = nNB[idx1];
							nNB[idx1] += 2;
							

							int k = 0;
							while(*(startIa+k) != idx2)
							{
								k += 2;
							}							
							
							*(startIa+k) = idx1;							
						}
					}					

					// DELETE!	
					maxNB[idx2] = 0;
					nNB[idx2] = 0;
					if(pagefault[idx2])
						delete[] startpage[idx2];
					M = M - 1;					
					int p_idx2 = lutIDX[idx2];
					lutIDX[IDX[M]] = p_idx2;
                    std::swap(IDX[p_idx2], IDX[M]);	
				}


				
			}

			// delete all neighbours which already marked -1
			int currentIdx = 0;
			for (int ii = 0; ii < nNB[idx1]; ii+=2)
			{
				if (hashID[*(startI1 + ii)] > -1)
				{
					*(startI1 + currentIdx) = *(startI1 + ii);
					*(startI1 + currentIdx + 1) = *(startI1 + ii + 1);
					currentIdx += 2;
				}
			}
			nNB[idx1] = currentIdx;

			// clean hashIDX
			for(int hi = 0; hi < nNB[idx1]; hi = hi+2)
			{
				hashID[*(startI1+hi)] = -1;
			}
		}
		iter++;

	}
	// restore image

	
	for (int i = 0; i < rows*cols; i++)
	{
		int root = i;
		while (G[root] != root) 
		{ 
			int temp = root;
			root = G[root];
			G[temp] = G[root];
		}
		G[i] = root;
		int lidx = i;
		int ridx = root;
		for (int b = 0; b < bands; b++)
			outImage[lidx + b*numOfPixels] = Y[ridx + b*numOfPixels];
	}

	for(int i = 0; i < M; i++)
	{	
		int idx1 = IDX[i];
		if(pagefault[idx1])
		{
			delete[] startpage[idx1];
		}
	}
	// clear the memory
	delete[] Y;
	delete [] NB;
	delete [] nNB;		
	delete[] W;
	delete[] sumY;
	delete[] IDX;
	delete[] lutIDX;
	delete[] hashID;
	delete[] pagefault;
	delete[] startpage;
	delete[] tempNB;
}

/* The gateway function */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[])
{
    double threshold;              /* input scalar */
    double *inImage;               /* MxN input matrix */
    double *outImage;              /* output matrix */
    double* outLabel;

    /* create a pointer to the real data in the input image  */
    inImage= mxGetPr(prhs[0]);
    
    const mwSize* arrayDimension = mxGetDimensions(prhs[0]);
    mwSize ndims = mxGetNumberOfDimensions(prhs[0]);

    /* get dimensions of the input matrix */
    size_t nrows = arrayDimension[0];
    size_t ncols = arrayDimension[1];
    size_t nbands = arrayDimension[2];
    
    /* get the value of the scalar input  */
    threshold = mxGetScalar(prhs[1]);
    
    /* create the output image */
    plhs[0] = mxCreateNumericArray(ndims, arrayDimension, mxDOUBLE_CLASS,mxREAL);
    const mwSize dimLabel[]         = {nrows, ncols};
    plhs[1] = mxCreateNumericArray(2, dimLabel, mxDOUBLE_CLASS,mxREAL);

    /* get a pointer to the real data in the output matrix */
    outImage = mxGetPr(plhs[0]);
    outLabel = mxGetPr(plhs[1]);
    
    /* call the computational routine */    
    l0_norm(inImage, outImage, outLabel, nrows, ncols, nbands, threshold);
}